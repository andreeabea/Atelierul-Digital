package code._2_challenge._2_strategy;

public interface SortingStrategy {

  void sort(Integer[] list);
}
