package code._2_challenge._4_observer;

public interface Observer {

  void update(String message);

}