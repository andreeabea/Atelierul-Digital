package code._1_study._4_gloves_and_socks;

public class PairDoesNotMatch extends RuntimeException {
    public PairDoesNotMatch(String message) {
        super(message);
    }
}