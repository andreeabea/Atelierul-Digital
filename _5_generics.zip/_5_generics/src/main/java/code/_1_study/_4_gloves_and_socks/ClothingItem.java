package code._1_study._4_gloves_and_socks;

public interface ClothingItem {
        int getSize();
        String getColor();
    }