package code._1_study._3_type_errasure;

public class TypeErrasure {

  public static void main(String[] args) {

    //run the following commands from cmd

    //_5_generics/target/classes/code/_1_study/_3_type_errasure>javap Node.class
    //_5_generics/target/classes/code/_1_study/_3_type_errasure>javap -c Node.class

    //_5_generics/target/classes/code/_1_study/_3_type_errasure>javap Node2.class
    //_5_generics/target/classes/code/_1_study/_3_type_errasure>javap -c Node2.class

  }

}
