package code._1_study._5_generic_array_iterator;

public interface IArrayIterator<T> {
        boolean hasNext();
        T next();
    }