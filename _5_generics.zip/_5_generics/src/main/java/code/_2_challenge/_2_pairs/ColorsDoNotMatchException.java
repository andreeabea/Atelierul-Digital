package code._2_challenge._2_pairs;

public class ColorsDoNotMatchException extends RuntimeException {
  public ColorsDoNotMatchException(String message) {
    super(message);
  }
}
