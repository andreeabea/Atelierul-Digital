package code._2_challenge._2_pairs;

public class SizesDoNotMatchException extends RuntimeException {
  public SizesDoNotMatchException(String message) {
    super(message);
  }
}
