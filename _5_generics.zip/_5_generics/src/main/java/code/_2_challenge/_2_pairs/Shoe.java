package code._2_challenge._2_pairs;

public interface Shoe {
  String getColor();

  double getSize();
}
