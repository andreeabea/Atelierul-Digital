package code._2_challenge._3_generic_linked_list;

public class GenericLinkedListChallenge {
}
