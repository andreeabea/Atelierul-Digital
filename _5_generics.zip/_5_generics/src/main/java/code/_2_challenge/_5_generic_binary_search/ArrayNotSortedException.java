package code._2_challenge._5_generic_binary_search;

public class ArrayNotSortedException extends Exception {
        public ArrayNotSortedException(String message) {
            super(message);
        }
    }