package code._2_challenge._4_generic_iterator;

public class GenericIteratorChallenge {
}
