package code._2_challenge._1_exchange_desk;

import java.lang.reflect.InvocationTargetException;

public class ExchangeDesk<F extends Currency, T extends Currency> {

  public ExchangeDesk() {
  }

  <T extends Currency, F extends Currency> T convert(F fromCurrency, Class<T> tClass, double rate) {
    T toCurrency = null;
    try {
      toCurrency = tClass.getDeclaredConstructor().newInstance();
      toCurrency.setUnits(fromCurrency.getUnits() * rate);
    } catch (InstantiationException e) {
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (NoSuchMethodException e) {
      e.printStackTrace();
    } catch (InvocationTargetException e) {
      e.printStackTrace();
    }
    return toCurrency;
  }
}
