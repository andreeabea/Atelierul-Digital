package code._1_study._6_try_with_resources_and_suppressed;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
}