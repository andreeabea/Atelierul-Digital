package code._3_in_class;

public class TryWithResources {

  public static void main(String[] args) {

    try (MyClosableResource r = new MyClosableResource()) {
      throw new RuntimeException("oops");
    } catch (Exception e) {

      //check for suppressed exceptions
      Throwable[] exceptions = e.getSuppressed();
      for(Throwable exception: exceptions) {
        System.out.println(exception.getMessage());
      }

      //print exception
      System.out.println(e.getMessage());
    }
  }
}
